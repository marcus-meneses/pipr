const express = require('express');
const os = require('os');

const app = express();
const hostname = os.hostname(); // Unique per container/pod

app.get('/', (req, res) => {
  res.send({ hostname });
});

app.listen(3000, () => {
  console.log(`Running on ${hostname}`);
});